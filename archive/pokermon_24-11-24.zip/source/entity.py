from card import Card
from deck import Deck
from hand import Hand

class Entity:
    def __init__(self):
        self.deck = Deck()
        