

class Battle:
    def __init__(self):
        self. 
        return

