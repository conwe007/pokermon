import pygame
import time
import random

class Game:
    def __init__(self):
        print("game created")
    
    def run(self):
        return